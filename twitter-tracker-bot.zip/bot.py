import logging
import os
import requests
from bs4 import BeautifulSoup
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, ContextTypes, filters

TOKEN = os.getenv("BOT_TOKEN")

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Halo! Kirim username Twitter (tanpa @) untuk melihat riwayat akun.")

def get_memory_lol_data(username):
    url = f"https://memory.lol/user/{username.lower()}"
    headers = {
        "User-Agent": "Mozilla/5.0"
    }
    r = requests.get(url, headers=headers)
    if r.status_code != 200:
        return None

    soup = BeautifulSoup(r.text, "html.parser")
    result = soup.find("div", class_="content")
    if not result:
        return None

    return result.get_text(separator="\n", strip=True)

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    username = update.message.text.strip().lstrip('@')
    await update.message.reply_text(f"🔍 Mencari data untuk @{username}...")

    data = get_memory_lol_data(username)
    if data:
        await update.message.reply_text(f"📄 Data untuk @{username}:

{data[:4000]}")
    else:
        await update.message.reply_text("❌ Tidak ditemukan data untuk username tersebut.")

if __name__ == '__main__':
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    app.run_polling()
